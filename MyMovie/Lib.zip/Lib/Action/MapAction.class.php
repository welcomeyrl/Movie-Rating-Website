<?php
class MapAction extends Action{
	public function map(){
		$this->display("map");
	}
}