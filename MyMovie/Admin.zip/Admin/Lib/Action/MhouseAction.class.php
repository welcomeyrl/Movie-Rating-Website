/<?php 
	/**
	* 影院管理控制器
	*/
	class MhouseAction extends CommonAction {
		
	}
?>