<?php
	// 设置影片类别控制器
	class SetTypeAction extends CommonAction {

		
	}
?>